import express, { type Request, Response, NextFunction } from "express";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
const httpServer = createServer(app);

// 🔌 WebSocket en ruta personalizada "/map/ws"
const wss = new WebSocketServer({ noServer: true });

httpServer.on("upgrade", (request, socket, head) => {
  if (request.url === "/map/ws") {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit("connection", ws, request);
    });
  } else {
    socket.destroy();
  }
});

wss.on("connection", (socket) => {
  console.log("🌐 Cliente WebSocket conectado");

  socket.on("message", (data) => {
    console.log("📨 Mensaje recibido:", data.toString());
  });

  socket.on("close", () => {
    console.log("❌ Cliente WebSocket desconectado");
  });

  socket.send("👋 Hola desde el servidor WebSocket");
});

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// 📝 Middleware para logging API
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  await registerRoutes(app);

  // ⚠️ Middleware de error
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // 💻 Modo desarrollo usa Vite
  if (app.get("env") === "development") {
    await setupVite(app, httpServer);
  } else {
    serveStatic(app);
  }

  const port = 8121;
  httpServer.listen(port, "127.0.0.1", () => {
    log(`✅ Servidor escuchando en http://127.0.0.1:${port}`);
    log(`🌐 WebSocket disponible en ws://127.0.0.1:${port}/map/ws`);
  });
})();
